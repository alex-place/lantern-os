﻿# Lantern OS Installer for Courtney

**Date:** 2026-05-30  
**Version:** 1.0.0

## Quick Start

1. **Double-click:** Invoke-CourtneySetupWizard.ps1
2. **Follow the prompts** in the wizard
3. **Start Lantern OS** using the desktop shortcut

## What This Installer Does

- Checks prerequisites (Node.js, Git, PowerShell)
- Clones the Lantern OS repository
- Configures Git for your user
- Creates a desktop shortcut
- Sets up local-cloud bridge

## Prerequisites

Before running the installer, ensure you have:
- **Node.js 20+** - Download from https://nodejs.org (LTS version)
- **Git** - Download from https://git-scm.com/download/win
- **PowerShell** - Included with Windows (no installation needed)

## Manual Setup

If the wizard fails, see:
- COURTNEY-DESKTOP-BRIDGE-SETUP-2026-05-30.md - Full bridge setup guide
- COURTNEY-QUICK-SYNC-2026-05-30.md - Quick sync commands

## Support

If you encounter issues:
1. Check the troubleshooting section in the bridge setup guide
2. Contact the Lantern OS operator for help

## After Installation

- Local app runs at: http://127.0.0.1:4177
- Cloud chat available via Codex Cloud
- Discord bot in collaboration channel

---

**Prepared for:** Courtney Blasioli  
**Date:** 2026-05-30
